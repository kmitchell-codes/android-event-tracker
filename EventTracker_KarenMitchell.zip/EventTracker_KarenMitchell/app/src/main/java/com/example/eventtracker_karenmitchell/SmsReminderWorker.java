
package com.example.eventtracker_karenmitchell;

import android.Manifest;
import android.content.Context;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.telephony.SmsManager;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

public class SmsReminderWorker extends Worker {

    public SmsReminderWorker(
            @NonNull Context context,
            @NonNull WorkerParameters workerParams) {
        super(context, workerParams);
    }

    @NonNull
    @Override
    public Result doWork() {

        Context context = getApplicationContext();

        // Identify the event and user.
        long eventId = getInputData().getLong("event_id", -1);
        long userId = getInputData().getLong("user_id", -1);

        if (eventId == -1 || userId == -1) {
            return Result.failure();
        }

        // Check the user's saved SMS preferences by ID.
        SharedPreferences settings = context.getSharedPreferences(
                "sms_settings_" + userId, Context.MODE_PRIVATE);

        boolean enabled = settings.getBoolean("sms_enabled", false);
        String phone = settings.getString("sms_phone", "");

        // Do not send when notifications are disabled.
        if (!enabled || !phone.matches("\\+?[0-9]{7,15}")) {
            return Result.success();
        }

        // Check Android's permission before sending.
        if (ContextCompat.checkSelfPermission(
                context, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            return Result.success();
        }

        // Some devices cannot send SMS.
        if (!context.getPackageManager().hasSystemFeature(
                PackageManager.FEATURE_TELEPHONY_MESSAGING)) {
            return Result.success();
        }

        DatabaseHelper databaseHelper = new DatabaseHelper(context);

        try (Cursor cursor = databaseHelper.getEvent(eventId, userId)) {

            // Don't send reminders for deleted events.
            if (!cursor.moveToFirst()) {
                return Result.success();
            }

            String name = cursor.getString(0);
            String date = cursor.getString(1);
            String time = cursor.getString(2);

            // Build the reminder message.
            String message = "EventTracker reminder: "
                    + name + " on " + date + " at " + time;

            // Request that Android send the SMS.
            SmsManager smsManager =
                    context.getSystemService(SmsManager.class);

            if (smsManager == null) {
                return Result.failure();
            }

            smsManager.sendTextMessage(
                    phone, null, message, null, null);

            return Result.success();

        } catch (SecurityException | IllegalArgumentException
                 | UnsupportedOperationException e) {

            Log.e("SmsReminderWorker", "SMS request failed", e);
            return Result.failure();

        } finally {
            databaseHelper.close();
        }
    }
}
