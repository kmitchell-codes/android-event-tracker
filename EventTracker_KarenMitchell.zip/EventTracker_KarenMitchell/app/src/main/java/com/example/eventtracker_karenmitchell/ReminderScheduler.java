
package com.example.eventtracker_karenmitchell;

import android.content.Context;

import androidx.work.Data;
import androidx.work.ExistingWorkPolicy;
import androidx.work.OneTimeWorkRequest;
import androidx.work.WorkManager;

import java.text.ParsePosition;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.concurrent.TimeUnit;

public class ReminderScheduler {

    // Schedule an SMS reminder 15 minutes before an event.
    public static boolean schedule(Context context, long eventId,
                                   long userId, String date, String time) {

        String input = date.trim() + " " + time.trim();

        // Support both date formats we've used in testing.
        String[] formats = {
                "MM-dd-yyyy HH:mm",
                "yyyy-MM-dd HH:mm",
                "MM/dd/yyyy h:mm a"
        };

        Date eventDate = null;

        for (String format : formats) {
            SimpleDateFormat parser =
                    new SimpleDateFormat(format, Locale.US);
            parser.setLenient(false);

            ParsePosition position = new ParsePosition(0);
            Date parsed = parser.parse(input, position);

            if (parsed != null && position.getIndex() == input.length()) {
                eventDate = parsed;
                break;
            }
        }

        // Do not schedule invalid or past events.
        if (eventDate == null ||
                eventDate.getTime() <= System.currentTimeMillis()) {
            cancel(context, eventId);
            return false;
        }

        // Calculate how long until 15 minutes before the event.
        long reminderTime = eventDate.getTime()
                - TimeUnit.MINUTES.toMillis(15);

        long delay = Math.max(0,
                reminderTime - System.currentTimeMillis());

        // Pass the event and user IDs to our Worker.
        Data inputData = new Data.Builder()
                .putLong("event_id", eventId)
                .putLong("user_id", userId)
                .build();

        OneTimeWorkRequest request =
                new OneTimeWorkRequest.Builder(SmsReminderWorker.class)
                        .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                        .setInputData(inputData)
                        .build();

        // Replace the old reminder if the event was edited.
        WorkManager.getInstance(context).enqueueUniqueWork(
                "event_reminder_" + eventId,
                ExistingWorkPolicy.REPLACE,
                request
        );

        return true;
    }

    // Cancel a pending reminder when an event is deleted.
    public static void cancel(Context context, long eventId) {
        WorkManager.getInstance(context).cancelUniqueWork(
                "event_reminder_" + eventId
        );
    }
}
