package com.example.eventtracker_karenmitchell;

import android.content.Intent;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.widget.LinearLayout;
import android.database.Cursor;
import android.widget.Button;
import android.widget.GridLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;

public class EventsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_events);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;


        });

        // Get the ID of the user who logged in.
        long userId = getIntent().getLongExtra("user_id", -1);

        // Open the Add Event screen when the plus button is tapped.
        findViewById(R.id.buttonOpenAddEvent).setOnClickListener(v -> {
            Intent intent = new Intent(this, AddEditEventActivity.class);
            intent.putExtra("user_id", userId);
            startActivity(intent);
        });


        // Open the SMS notification settings screen.
        findViewById(R.id.buttonSmsSettings).setOnClickListener(v -> {
            Intent intent = new Intent(this, SmsPermissionActivity.class);
            intent.putExtra("user_id", userId);
            startActivity(intent);
        });


        // TODO: Pass existing event ID to AddEditEventActivity when editing

    }

    @Override
    protected void onResume() {
        super.onResume();
        loadEvents();
    }

    // Load this user's saved events into the grid.
    private void loadEvents() {
        long userId = getIntent().getLongExtra("user_id", -1);

        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        GridLayout eventGrid = findViewById(R.id.eventGrid);

        // Clear old event rows, but keep the four headers.
        while (eventGrid.getChildCount() > 4) {
            eventGrid.removeViewAt(4);
        }

        // Retrieve events from SQLite.
        try (Cursor cursor = databaseHelper.getEvents(userId)) {
            while (cursor.moveToNext()) {
                long eventId = cursor.getLong(0);
                String name = cursor.getString(1);
                String date = cursor.getString(2);
                String time = cursor.getString(3);

                // Add the event information to the grid.
                addCell(eventGrid, name);
                addCell(eventGrid, date);
                addCell(eventGrid, time);


                // Place Edit and Delete buttons in one grid cell.
                LinearLayout actions = new LinearLayout(this);
                actions.setOrientation(LinearLayout.VERTICAL);
                actions.setPadding(0, 4, 0, 4);

                LinearLayout.LayoutParams buttonParams =
                        new LinearLayout.LayoutParams(
                                LinearLayout.LayoutParams.WRAP_CONTENT,
                                LinearLayout.LayoutParams.WRAP_CONTENT
                        );
                buttonParams.setMargins(0, 0, 0, 8);

                // Create an Edit button for this event.
                Button editButton = new Button(this);
                editButton.setText("Edit");
                editButton.setTextSize(11);
                editButton.setAllCaps(false);
                editButton.setMinimumWidth(0);
                editButton.setMinimumHeight(0);
                editButton.setPadding(20, 8, 20, 8);
                editButton.setLayoutParams(buttonParams);
                actions.addView(editButton);

                // Keep our existing Delete functionality.
                Button deleteButton = new Button(this);
                deleteButton.setText("Delete");
                deleteButton.setTextSize(11);
                deleteButton.setAllCaps(false);
                deleteButton.setMinimumWidth(0);
                deleteButton.setMinimumHeight(0);
                deleteButton.setPadding(20, 8, 20, 8);
                deleteButton.setLayoutParams(buttonParams);
                actions.addView(deleteButton);

                eventGrid.addView(actions);

                // Open the editing screen for this specific event.
                editButton.setOnClickListener(v -> {
                    Intent intent = new Intent(this, AddEditEventActivity.class);
                    intent.putExtra("user_id", userId);
                    intent.putExtra("event_id", eventId);
                    startActivity(intent);
                });

                deleteButton.setOnClickListener(v -> {
                    new AlertDialog.Builder(this)
                            .setTitle("Delete Event?")
                            .setMessage("Delete " + name + "?")
                            .setPositiveButton("Delete", (dialog, which) -> {
                                int deleted = databaseHelper.deleteEvent(
                                        eventId, userId);

                                if (deleted > 0) {
                                    // Cancel the reminder for the deleted event.
                                    ReminderScheduler.cancel(this, eventId);
                                    loadEvents();
                                }
                                else {
                                    Toast.makeText(this,
                                            "Could not delete event",
                                            Toast.LENGTH_SHORT).show();
                                }
                            })
                            .setNegativeButton("Cancel", null)
                            .show();
                });
            }
        }
    }

    // Create a text cell in the event grid.
    private void addCell(GridLayout grid, String value) {
        TextView cell = new TextView(this);
        cell.setText(value);
        cell.setTextSize(14);
        cell.setPadding(4, 12, 4, 12);

        GridLayout.LayoutParams params = new GridLayout.LayoutParams();
        params.width = 0;
        params.height = GridLayout.LayoutParams.WRAP_CONTENT;
        params.columnSpec = GridLayout.spec(GridLayout.UNDEFINED, 1f);

        cell.setLayoutParams(params);
        grid.addView(cell);
    }

}

