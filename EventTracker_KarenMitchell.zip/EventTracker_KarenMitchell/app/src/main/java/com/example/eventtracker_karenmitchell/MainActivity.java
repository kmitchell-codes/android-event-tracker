package com.example.eventtracker_karenmitchell;

import android.os.Bundle;

import android.widget.Toast;
import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.content.Intent;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        // Open the database and create its tables if needed.
        DatabaseHelper databaseHelper = new DatabaseHelper(this);
        databaseHelper.getWritableDatabase().close();

        // Connect the Java variables to our XML screen.
        EditText editUsername = findViewById(R.id.editUsername);
        EditText editPassword = findViewById(R.id.editPassword);
        Button buttonLogin = findViewById(R.id.buttonLogin);
        Button buttonCreateAccount = findViewById(R.id.buttonCreateAccount);

        // Create a new user account.
        buttonCreateAccount.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString();

            // Make sure both fields contain information.
            if (username.isEmpty() || password.trim().isEmpty()) {
                Toast.makeText(this, "Enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Do not allow spaces in new passwords.
            if (password.contains(" ")) {
                Toast.makeText(this, "Password cannot contain spaces",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Save the new account in SQLite.
            long userId = databaseHelper.addUser(username, password);

            if (userId != -1) {
                Toast.makeText(this, "Account created successfully",
                        Toast.LENGTH_SHORT).show();
                openEvents(userId);
            } else {
                Toast.makeText(this, "Username already exists",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Log in with an existing account.
        buttonLogin.setOnClickListener(v -> {
            String username = editUsername.getText().toString().trim();
            String password = editPassword.getText().toString();

            if (username.isEmpty() || password.isEmpty()) {
                Toast.makeText(this, "Enter a username and password",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Check the username and password against SQLite.
            long userId = databaseHelper.checkLogin(username, password);

            if (userId != -1) {
                Toast.makeText(this, "Login successful",
                        Toast.LENGTH_SHORT).show();
                openEvents(userId);
            } else {
                Toast.makeText(this, "Incorrect username or password",
                        Toast.LENGTH_SHORT).show();
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    // Open the Events screen for the logged-in user.
    private void openEvents(long userId) {
        // Clear the password before leaving the login screen.
        EditText passwordField = findViewById(R.id.editPassword);
        passwordField.setText("");

        Intent intent = new Intent(this, EventsActivity.class);
        intent.putExtra("user_id", userId);
        startActivity(intent);
    }

}