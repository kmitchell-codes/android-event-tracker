package com.example.eventtracker_karenmitchell;

import android.os.Bundle;

import android.app.DatePickerDialog;
import android.app.TimePickerDialog;

// Calendar functionality
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.widget.Button;
import android.widget.EditText;
import android.database.Cursor;
import android.widget.TextView;
import androidx.appcompat.app.AlertDialog;
import android.widget.Toast;

public class AddEditEventActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_add_edit_event);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });


        // Identify the user who is adding the event.
        long userId = getIntent().getLongExtra("user_id", -1);
        // An event ID means we are editing an existing event.
        long eventId = getIntent().getLongExtra("event_id", -1);

        // Connect Java variables to the event form.
        EditText editName = findViewById(R.id.editEventName);
        EditText editDate = findViewById(R.id.editEventDate);
        EditText editTime = findViewById(R.id.editEventTime);
        EditText editDetails = findViewById(R.id.editEventDetails);

        Button buttonSave = findViewById(R.id.buttonSaveEvent);
        Button buttonCancel = findViewById(R.id.buttonCancelEvent);

        DatabaseHelper databaseHelper = new DatabaseHelper(this);


        // If editing, load the event's saved information.
        if (eventId != -1) {
            TextView title = findViewById(R.id.textAddEditTitle);
            title.setText("Edit Event");
            buttonSave.setText("Update Event");

            try (Cursor cursor = databaseHelper.getEvent(eventId, userId)) {
                if (cursor.moveToFirst()) {
                    editName.setText(cursor.getString(0));
                    editDate.setText(cursor.getString(1));
                    editTime.setText(cursor.getString(2));
                    editDetails.setText(cursor.getString(3));
                } else {
                    Toast.makeText(this, "Event not found",
                            Toast.LENGTH_SHORT).show();
                    finish();
                    return;
                }
            }
        }


        // Open a calendar when the date field is tapped.
        editDate.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();

            // If editing, try to select the event's saved date.
            String currentDate = editDate.getText().toString();

            String[] formats = {
                    "yyyy-MM-dd",
                    "MM-dd-yyyy",
                    "MM/dd/yyyy"
            };

            for (String format : formats) {
                try {
                    SimpleDateFormat parser =
                            new SimpleDateFormat(format, Locale.US);
                    parser.setLenient(false);

                    Date savedDate = parser.parse(currentDate);

                    if (savedDate != null) {
                        calendar.setTime(savedDate);
                        break;
                    }
                } catch (ParseException ignored) {
                    // Try the next date format.
                }
            }

            // Show Android's calendar selection dialog.
            DatePickerDialog datePicker = new DatePickerDialog(
                    this,
                    (view, year, month, day) -> {

                        // Calendar months start at 0, so add 1.
                        String selectedDate = String.format(
                                Locale.US,
                                "%04d-%02d-%02d",
                                year, month + 1, day);

                        editDate.setText(selectedDate);
                    },
                    calendar.get(Calendar.YEAR),
                    calendar.get(Calendar.MONTH),
                    calendar.get(Calendar.DAY_OF_MONTH)
            );

            datePicker.show();
        });


        // Open a clock when the time field is tapped.
        editTime.setOnClickListener(v -> {

            Calendar calendar = Calendar.getInstance();

            // If editing, use the event's previously saved time.
            String currentTime = editTime.getText().toString().trim();

            if (!currentTime.isEmpty()) {
                String[] timeFormats = {"HH:mm", "h:mm a"};

                for (String format : timeFormats) {
                    try {
                        SimpleDateFormat parser =
                                new SimpleDateFormat(format, Locale.US);
                        parser.setLenient(false);

                        Date savedTime = parser.parse(currentTime);

                        if (savedTime != null) {
                            Calendar savedCalendar = Calendar.getInstance();
                            savedCalendar.setTime(savedTime);

                            calendar.set(Calendar.HOUR_OF_DAY,
                                    savedCalendar.get(Calendar.HOUR_OF_DAY));
                            calendar.set(Calendar.MINUTE,
                                    savedCalendar.get(Calendar.MINUTE));
                            break;
                        }
                    } catch (ParseException ignored) {
                        // Try the next time format.
                    }
                }
            }

            // Show Android's time selection dialog.
            TimePickerDialog timePicker = new TimePickerDialog(
                    this,
                    (view, hour, minute) -> {

                        // Store time in 24-hour format for reminders.
                        String selectedTime = String.format(
                                Locale.US,
                                "%02d:%02d",
                                hour, minute);

                        editTime.setText(selectedTime);
                    },
                    calendar.get(Calendar.HOUR_OF_DAY),
                    calendar.get(Calendar.MINUTE),
                    true
            );

            timePicker.show();
        });

        // Save the event when the user taps Save.
        buttonSave.setOnClickListener(v -> {
            String name = editName.getText().toString().trim();
            String date = editDate.getText().toString().trim();
            String time = editTime.getText().toString().trim();
            String details = editDetails.getText().toString().trim();

            // Required fields cannot be empty.
            if (name.isEmpty() || date.isEmpty() || time.isEmpty()) {
                Toast.makeText(this, "Enter a name, date, and time",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            // Add a new event or update an existing one.
            boolean isEditing = eventId != -1;
            long result;

            if (isEditing) {
                result = databaseHelper.updateEvent(
                        eventId, userId, name, date, time, details);
            } else {
                result = databaseHelper.addEvent(
                        userId, name, date, time, details);
            }

            if (result > 0) {
                String message = isEditing
                        ? "Event updated successfully"
                        : "Event saved successfully";

                // Find the ID of the saved event.
                long savedEventId = isEditing ? eventId : result;

                // Schedule an SMS reminder for this event.
                boolean scheduled = ReminderScheduler.schedule(
                        this, savedEventId, userId, date, time);

                if (scheduled) {
                    message += ". Reminder requested.";
                } else {
                    message += ". No future reminder scheduled.";
                }

                // Show the scheduling result before closing.
                new AlertDialog.Builder(this)
                        .setTitle("Event Saved")
                        .setMessage(message)
                        .setPositiveButton("OK", (dialog, which) -> {
                            finish();
                        })
                        .show();


            } else {
                Toast.makeText(this, "Could not save event",
                        Toast.LENGTH_SHORT).show();
            }
        });

        // Return to the Events screen without saving.
        buttonCancel.setOnClickListener(v -> finish());

    }
}