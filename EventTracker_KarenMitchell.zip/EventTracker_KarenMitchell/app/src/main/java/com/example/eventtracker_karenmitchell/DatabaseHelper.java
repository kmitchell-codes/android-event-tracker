package com.example.eventtracker_karenmitchell;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.content.ContentValues;
import android.database.Cursor;
import android.util.Base64;

import java.security.GeneralSecurityException;
import java.security.MessageDigest;

//Generates random password salt
import java.security.SecureRandom; //Generates random password salt

//Handle password hashing using PBKDF2
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;

// Manages the local database for users and events.
public class DatabaseHelper extends SQLiteOpenHelper {
    private static final String DATABASE_NAME = "event_tracker.db";
    //Allows for future expansion tot he database
    private static final int DATABASE_VERSION = 1;

    // Constructor: connects the helper to our database.
    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onConfigure(SQLiteDatabase db) {
        super.onConfigure(db);
        db.setForeignKeyConstraintsEnabled(true);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {

        // Store user accounts without keeping plain-text passwords.
        db.execSQL("CREATE TABLE users (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "username TEXT NOT NULL UNIQUE, " +
                "password_hash TEXT NOT NULL, " +
                "password_salt TEXT NOT NULL)");

        // Store events associated with individual users.
        db.execSQL("CREATE TABLE events (" +
                "_id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "user_id INTEGER NOT NULL, " +
                "event_name TEXT NOT NULL, " +
                "event_date TEXT NOT NULL, " +
                "event_time TEXT NOT NULL, " +
                "details TEXT, " +
                "FOREIGN KEY(user_id) REFERENCES users(_id) " +
                "ON DELETE CASCADE)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db,
                          int oldVersion, int newVersion) {
        // Version 1: add migrations if the database schema changes.
    }

    // Save a new user account.
    public long addUser(String username, String password) {
        byte[] salt = new byte[16];
        new SecureRandom().nextBytes(salt);

        ContentValues values = new ContentValues();
        values.put("username", username);
        values.put("password_hash", hashPassword(password, salt));
        values.put("password_salt",
                Base64.encodeToString(salt, Base64.NO_WRAP));

        return getWritableDatabase().insert("users", null, values);
    }

    // Check login details and return the user's ID.
    public long checkLogin(String username, String password) {
        Cursor cursor = getReadableDatabase().query(
                "users",
                new String[]{"_id", "password_hash", "password_salt"},
                "username = ?",
                new String[]{username},
                null, null, null
        );

        try {
            if (cursor.moveToFirst()) {
                byte[] salt = Base64.decode(
                        cursor.getString(2), Base64.NO_WRAP);

                String hash = hashPassword(password, salt);

                byte[] savedHash = Base64.decode(
                        cursor.getString(1), Base64.NO_WRAP);
                byte[] enteredHash = Base64.decode(
                        hash, Base64.NO_WRAP);

                if (MessageDigest.isEqual(savedHash, enteredHash)) {
                    return cursor.getLong(0);
                }
            }
            return -1;
        } finally {
            cursor.close();
        }
    }

    // Turn a password and salt into a protected hash.
    private String hashPassword(String password, byte[] salt) {
        PBEKeySpec spec = new PBEKeySpec(
                password.toCharArray(), salt, 120000, 256);

        try {
            SecretKeyFactory factory = SecretKeyFactory.getInstance(
                    "PBKDF2WithHmacSHA256");

            byte[] hash = factory.generateSecret(spec).getEncoded();
            return Base64.encodeToString(hash, Base64.NO_WRAP);

        } catch (GeneralSecurityException e) {
            throw new IllegalStateException(
                    "Password hashing failed", e);
        } finally {
            spec.clearPassword();
        }
    }


    // Add a new event to the database.
    public long addEvent(long userId, String name,
                         String date, String time, String details) {

        ContentValues values = new ContentValues();
        values.put("user_id", userId);
        values.put("event_name", name);
        values.put("event_date", date);
        values.put("event_time", time);
        values.put("details", details);

        return getWritableDatabase().insert("events", null, values);
    }


    // Get all events belonging to a specific user.
    public Cursor getEvents(long userId) {
        return getReadableDatabase().query(
                "events",
                new String[]{"_id", "event_name",
                        "event_date", "event_time"},
                "user_id = ?",
                new String[]{String.valueOf(userId)},
                null, null, "_id DESC"
        );
    }


    // Delete an event belonging to the current user.
    public int deleteEvent(long eventId, long userId) {
        return getWritableDatabase().delete(
                "events",
                "_id = ? AND user_id = ?",
                new String[]{String.valueOf(eventId),
                        String.valueOf(userId)}
        );
    }


    // Find one event so its information can be edited.
    public Cursor getEvent(long eventId, long userId) {
        return getReadableDatabase().query(
                "events",
                new String[]{"event_name", "event_date",
                        "event_time", "details"},
                "_id = ? AND user_id = ?",
                new String[]{String.valueOf(eventId),
                        String.valueOf(userId)},
                null, null, null
        );
    }

    // Update an existing event in the database.
    public int updateEvent(long eventId, long userId,
                           String name, String date,
                           String time, String details) {

        ContentValues values = new ContentValues();
        values.put("event_name", name);
        values.put("event_date", date);
        values.put("event_time", time);
        values.put("details", details);

        return getWritableDatabase().update(
                "events",
                values,
                "_id = ? AND user_id = ?",
                new String[]{String.valueOf(eventId),
                        String.valueOf(userId)}
        );
    }


}
