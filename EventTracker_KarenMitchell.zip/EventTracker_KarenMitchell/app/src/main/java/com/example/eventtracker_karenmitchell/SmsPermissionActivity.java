package com.example.eventtracker_karenmitchell;

import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import android.Manifest;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.core.content.ContextCompat;


public class SmsPermissionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_sms_permission);


        // Display the current SMS permission status.
        TextView smsStatus = findViewById(R.id.textSmsStatus);

        // Keep SMS settings separate for each user.
        long userId = getIntent().getLongExtra("user_id", -1);

        SharedPreferences settings = getSharedPreferences(
                "sms_settings_" + userId, MODE_PRIVATE);

        // Let the user enter a phone number for reminders.
        EditText editSmsPhone = findViewById(R.id.editSmsPhone);

        // Display the previously saved number, if there is one.
        editSmsPhone.setText(settings.getString("sms_phone", ""));

        // Save the phone number for future reminders.
        findViewById(R.id.buttonSaveSmsPhone).setOnClickListener(v -> {
            String phone = editSmsPhone.getText().toString().trim();

            // Require 7-15 digits, with an optional leading +.
            if (!phone.matches("\\+?[0-9]{7,15}")) {
                Toast.makeText(this, "Enter a valid phone number",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            settings.edit().putString("sms_phone", phone).apply();

            Toast.makeText(this, "Phone number saved",
                    Toast.LENGTH_SHORT).show();
        });


        // Handle the user's response to Android's permission request.
        ActivityResultLauncher<String> smsPermissionLauncher =
                registerForActivityResult(
                        new ActivityResultContracts.RequestPermission(),
                        isGranted -> {
                            settings.edit()
                                    .putBoolean("sms_enabled", isGranted)
                                    .apply();

                            if (isGranted) {
                                smsStatus.setText("SMS permission enabled.");
                            } else {
                                smsStatus.setText(
                                        "SMS denied. Events still work normally.");
                            }
                        });

        // Check whether SMS is already allowed.
        boolean hasPermission = ContextCompat.checkSelfPermission(
                this, Manifest.permission.SEND_SMS)
                == PackageManager.PERMISSION_GRANTED;

        boolean smsEnabled = settings.getBoolean("sms_enabled", false);

        if (hasPermission && smsEnabled) {
            smsStatus.setText("SMS permission enabled.");
        } else {
            smsStatus.setText("SMS notifications are currently off.");
        }

        // Ask for permission when Allow is tapped.
        findViewById(R.id.buttonAllowSms).setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(
                    this, Manifest.permission.SEND_SMS)
                    == PackageManager.PERMISSION_GRANTED) {

                settings.edit().putBoolean("sms_enabled", true).apply();
                smsStatus.setText("SMS permission enabled.");

            } else {
                smsPermissionLauncher.launch(Manifest.permission.SEND_SMS);
            }
        });

        // Continue using the app without SMS reminders.
        findViewById(R.id.buttonDeclineSms).setOnClickListener(v -> {
            settings.edit().putBoolean("sms_enabled", false).apply();

            Toast.makeText(this, "SMS reminders disabled",
                    Toast.LENGTH_SHORT).show();

            finish();
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}